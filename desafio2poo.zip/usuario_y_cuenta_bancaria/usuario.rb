require_relative 'cuenta_bancaria'

class Usuario
  attr_accessor :nombre_del_usuario, :cuentas_bancarias
  def initialize(nombre_del_usuario, cuentas_bancarias)
    if cuentas_bancarias.count == 0
      raise Exception "Debe haber al menos una cuenta bancaria"
    elsif cuentas_bancarias.count > 2
      raise Exception "Solo pueden haber hasta dos(2) cuentas bancarias"
    end
    @nombre_del_usuario = nombre_del_usuario
    @cuentas_bancarias = cuentas_bancarias
  end

  def saldo_total
    saldo_total = 0
    @cuentas_bancarias.each do |cuenta|
      saldo_total += cuenta.saldo
    end
    saldo_total
  end
end

#creando cuentas
cuenta1 = CuentaBancaria.new('BBVA', 123456789, 5950)
cuenta2 = CuentaBancaria.new('Itau', 987654321, 5000)
cuenta3 = CuentaBancaria.new('BCI', 763852741, 40000)

#creando usuarios
usuario1 = Usuario.new('Luis', [cuenta1, cuenta3])
usuario2 = Usuario.new('Felipe', [cuenta2])

# saldos en cuentas bancarias
puts "Aquí tenemos dos cuentas bancarias y están así:"
puts "Saldo de la cuenta 1 es de $: #{cuenta1.saldo}, pertenece a #{usuario1.nombre_del_usuario} y es del banco #{cuenta1.nombre_del_banco}"
puts "Saldo de la cuenta 2 es de $: #{cuenta2.saldo}, pertenece a #{usuario2.nombre_del_usuario} y es del banco #{cuenta2.nombre_del_banco}"
puts "*-*-*-*-*-*"

# transferencia a otra cuenta
puts "Realizamos una transferencia de 5000 de la cuenta 1 a la cuenta 2:"
cuenta1.transferir(5000, cuenta2)

puts "Nuevo saldo de la cuenta 1 es de $: #{cuenta1.saldo}, cuyo dueño es #{usuario1.nombre_del_usuario}"
puts "Nuevo saldo de la cuenta 2 es de $: #{cuenta2.saldo}, cuyo dueño es #{usuario2.nombre_del_usuario}"
puts "*-*-*-*-*-*"

puts "Realizamos una transferencia entre dos cuentas bancarias que tiene #{usuario1.nombre_del_usuario}:"
puts "Saldo en el banco #{cuenta3.nombre_del_banco} antes de la transferencia desde el banco #{cuenta1.nombre_del_banco} es de $: #{cuenta3.saldo}"
puts "Saldo nuevo total en el banco #{cuenta3.nombre_del_banco}, luego de la transferencia, es de $: #{usuario1.saldo_total}"