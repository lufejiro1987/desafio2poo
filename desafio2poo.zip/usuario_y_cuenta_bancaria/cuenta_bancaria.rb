class CuentaBancaria
  attr_accessor :nombre_del_banco, :numero_de_cuenta, :saldo

  def initialize(nombre_del_banco, numero_de_cuenta, saldo)
    @nombre_del_banco = nombre_del_banco
    @numero_de_cuenta = numero_de_cuenta
    @saldo = saldo
  end

  def transferir(monto, cuenta_destino)
    @saldo -= monto
    cuenta_destino.saldo += monto
  end
end