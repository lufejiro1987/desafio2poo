class Carta
  attr_accessor :numero, :pinta

  VALORES_POSIBLES_PINTA = ['C', 'D', 'E', 'T']

  def initialize(numero, pinta)
    if numero < 1 || numero > 13
      raise Exception "Escoja un número entre 1 y 13"
    end
    if pinta.length > 1
      raise Exception "El valor de la pinta puede ser sólo una letra"
    else
      if !(VALORES_POSIBLES_PINTA.include? pinta)
        raise Exception "La letra de la pinta no está entre las posibles opciones. Sólo (C)orazones, (D)iamantes, (E)spadas o (T)réboles."
      end
    end
    @numero = numero
    @pinta = pinta
  end
end