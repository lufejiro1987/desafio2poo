require_relative 'carta'

class Baraja
  
  attr_accessor :cartas

  VALORES_POSIBLES_PINTA = ['C', 'D', 'E', 'T']
  NUMEROS_CARTA = (1..13).to_a

  def initialize
    VALORES_POSIBLES_PINTA.each do |pinta|
      NUMEROS_CARTA.each do |numero|
        carta = Carta.new(numero, pinta)
        if @cartas.nil?
          @cartas = []
        end
        @cartas << carta
      end
    end
  end

  def desordenar
    @cartas = @cartas.shuffle
    puts "Cartas desordenadas"
  end

  def retirar_primera_carta
    if @cartas.count == 0
      raise Exception "No hay más cartas en la baraja"
    end
    retirada = @cartas.pop
    puts "Carta retirada. Numero = #{retirada.numero}. Pinta = #{retirada.pinta}"
    puts "Cantidad de cartas en la baraja: #{@cartas.count}"
  end

  def repartir_mano
    if @cartas.count == 0
      raise Exception "No hay más cartas en la baraja"
    end
    mano = @cartas.slice!(0..4)
    mano
  end
end

baraja = Baraja.new

puts "Cantidad de cartas en la baraja: #{baraja.cartas.count}"
puts "*-*-*-*-*"

# Desordenar
baraja.desordenar
puts "*-*-*-*-*"

# Retirar la primera carta (la ejecutamos varias veces para probar)
baraja.retirar_primera_carta
puts "*-*-*-*-*"
baraja.retirar_primera_carta
puts "*-*-*-*-*"
baraja.retirar_primera_carta
puts "*-*-*-*-*"

# Repartimos una mano
mano = baraja.repartir_mano
puts "Mano repartida"
mano.each_with_index do |carta, i|
  puts "Carta #{i+1}. Número = #{carta.numero}. Pinta = #{carta.pinta}"
end
puts "Cantidad de cartas restantes en la baraja: #{baraja.cartas.count}"
puts "*-*-*-*-*"